﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GesEntreprise.Entity;

namespace GesEntreprise.SamaService
{
    class ServiceBD
    {
        ModelEntreprise dao = new ModelEntreprise();

        public ServiceBD()
        {
        }

        public bool CreerService(Service service)
        {
            dao.Service.Add(service);
            return dao.SaveChanges() != 0;
        }

        public void ListerService(DataGridView dtgvService)
        {
            dtgvService.DataSource = dao.Service.ToList();
        }

        public bool UpdateService(Service service)
        {
            Service serviceUp = dao.Service.ToList().Where(u => u.Id == service.Id).First();
            serviceUp.Code = service.Code;
            serviceUp.Libelle = service.Libelle;
            return dao.SaveChanges() != 0;
        }
    }
}
