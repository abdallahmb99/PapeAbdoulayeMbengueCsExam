namespace GesEntreprise.Entity
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class ModelEntreprise : DbContext
    {
        public ModelEntreprise()
            : base("name=ModelEntreprise")
        {
        }

        public virtual DbSet<Employe> Employe { get; set; }
        public virtual DbSet<Service> Service { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Employe>()
                .HasMany(e => e.Service2)
               .WithOptional(e => e.Employe1)
                .HasForeignKey(e => e.Nbr_Employe);

            modelBuilder.Entity<Service>()
                .HasMany(e => e.Employe)
                .WithOptional(e => e.Service1)
                .HasForeignKey(e => e.Service);
        }
    }
}
