namespace GesEntreprise.Entity
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Employe")]
    public partial class Employe
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Employe()
        {
            Service2 = new HashSet<Service>();
        }

        public int Id { get; set; }

        [Required]
        [StringLength(50)]
        public string Matricule { get; set; }

        [Required]
        [StringLength(50)]
        public string Prenom { get; set; }

        [Required]
        [StringLength(50)]
        public string Nom { get; set; }

        [Required]
        [StringLength(50)]
        public string Sexe { get; set; }

        public int Nbr_Enfant { get; set; }

        public int Anciennete { get; set; }

        public double Sal_Base { get; set; }

        [Required]
        [StringLength(50)]
        public string Statut { get; set; }

        public double Prime_Speciale { get; set; }

        public double Prime { get; set; }

        public double Ipres { get; set; }

        public int? Service { get; set; }

        public virtual Service Service1 { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Service> Service2 { get; set; }
    }
}
