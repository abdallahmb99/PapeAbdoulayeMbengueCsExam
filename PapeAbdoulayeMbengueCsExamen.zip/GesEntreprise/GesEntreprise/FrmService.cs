﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GesEntreprise.Entity;
using GesEntreprise.SamaService;

namespace GesEntreprise
{
    public partial class FrmService : Form
    {
        ServiceBD leservice = new ServiceBD();
        public FrmService()
        {
            InitializeComponent();
        }

        private void btnAjouter_Click(object sender, EventArgs e)
        {
            Service service = new Service()
            {

                Code = txtCode.Text,
                Libelle = txtLibelle.Text   
            };

            leservice.CreerService(service);
            leservice.ListerService(dtgvService);
        }
        private Service serviceSelect = new Service();
        private void btnUp_Click(object sender, EventArgs e)
        {
            Service service = new Service()
            {
                Id = serviceSelect.Id,
                Code = txtCode.Text,
                Libelle = txtLibelle.Text
               
            };
            leservice.UpdateService(service);
            leservice.ListerService(dtgvService);
        }
    }
}
